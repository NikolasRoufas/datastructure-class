
"""
Name:  AM: 
Nikolaos Roufas & inf2024146 
Konstantinos Tzortis & inf2024168 
Nikolaos Levadiotis & inf2024168 
Date Created: 2025-04-02
Last Modified: 2025-04-02 
"""
from benchmark import run_benchmark

if __name__ == "__main__":
    print("Έναρξη εκτέλεσης των δοκιμών ταξινόμησης...")
    run_benchmark()
    print("\nΗ εκτέλεση ολοκληρώθηκε!")
    print("Τα αποτελέσματα έχουν αποθηκευτεί στο αρχείο 'benchmark_results.txt'")
    print("Τα διαγράμματα έχουν δημιουργηθεί στον τρέχοντα κατάλογο")